<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        form {
            margin: auto;
            width: 300px;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
        }
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="submit"] {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        a {
            display: block;
            margin-top: 10px;
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
    <h2>Change Password</h2>
    <form action="#" method="post">
        <label for="current_password">Current Password</label><br>
        <input type="password" id="current_password" name="current_password" required><br>

        <label for="new_password">New Password</label><br>
        <input type="password" id="new_password" name="new_password" required><br>

        <label for="retype_password">Retype New Password</label><br>
        <input type="password" id="retype_password" name="retype_password" required><br>

        <input type="submit" value="Change">
    </form>
    <a href="admin_home.html">Home</a>
</body>
</html>
