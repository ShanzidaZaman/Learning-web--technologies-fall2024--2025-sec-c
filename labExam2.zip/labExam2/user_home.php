<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
        }
        h1 {
            color: black;
        }
        a {
            display: block;
            color: purple;
            margin: 5px;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .header {
            background-color: lightblue;
            color: black;
            padding: 10px;
        }
        .container {
            margin-top: 30px;
            border: 1px solid #ccc;
            display: inline-block;
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <h2>Users' home page</h2>
    </div>

    <!-- User Content -->
    <div class="container">
        <h1>Welcome Anne!</h1>
        <a href="#">Profile</a>
        <a href="#">Change Password</a>
        <a href="#">Logout</a>
    </div>
</body>
</html>
