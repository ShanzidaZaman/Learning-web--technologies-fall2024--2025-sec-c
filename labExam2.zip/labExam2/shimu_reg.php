<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h3 {
            margin-bottom: 10px;
            border-bottom: 2px solid black;
            display: inline-block;
        }
        form {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 15px;
            width: 300px;
            border-radius: 5px;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="submit"] {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        input[type="radio"] {
            margin: 0 5px;
        }
        a {
            color: blue;
            text-decoration: none;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <h3>REGISTRATION</h3>
    <form action="login.html" method="post">
        <label for="id">Id</label>
        <input type="text" id="id" name="id" required>
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        
        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" required>
        
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
        
        <label>User Type</label><br>
        <input type="radio" id="user" name="user_type" value="user" checked>
        <label for="user">User</label>
        <input type="radio" id="admin" name="user_type" value="admin">
        <label for="admin">Admin</label><br><br>
        
        <input type="submit" value="Sign Up">
        <a href="login.php">Sign In</a>
    </form>
</body>
</html>
