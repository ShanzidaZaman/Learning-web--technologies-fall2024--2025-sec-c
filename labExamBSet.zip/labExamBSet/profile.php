<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        table {
            margin: auto;
            border-collapse: collapse;
            width: 300px;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .link {
            margin-top: 10px;
        }
        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
    <h2>Profile</h2>
    <table>
        <tr>
            <th>ID</th>
            <td>16-10101-2</td>
        </tr>
        <tr>
            <th>NAME</th>
            <td>Bob</td>
        </tr>
        <tr>
            <th>USER TYPE</th>
            <td>Admin</td>
        </tr>
    </table>
    <div class="link">
        <a href="admin_home.html">Go Home</a>
    </div>
</body>
</html>
