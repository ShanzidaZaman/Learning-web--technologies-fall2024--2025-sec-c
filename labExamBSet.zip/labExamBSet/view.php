<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        table {
            margin: auto;
            border-collapse: collapse;
            width: 50%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .link {
            margin-top: 10px;
        }
        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
    <h2>Users</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>USER TYPE</th>
        </tr>
        <tr>
            <td>15-10101-1</td>
            <td>Bob</td>
            <td>Admin</td>
        </tr>
        <tr>
            <td>16-10102-2</td>
            <td>Anne</td>
            <td>User</td>
        </tr>
        <tr>
            <td>16-10103-2</td>
            <td>Kent</td>
            <td>User</td>
        </tr>
        <tr>
            <td>16-10104-3</td>
            <td>James</td>
            <td>Admin</td>
        </tr>
    </table>
    <div class="link">
        <a href="admin_home.html">Go Home</a>
    </div>
</body>
</html>
