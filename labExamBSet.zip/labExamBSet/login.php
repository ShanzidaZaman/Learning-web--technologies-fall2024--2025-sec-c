<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h3 {
            margin-bottom: 10px;
            border-bottom: 2px solid black;
            display: inline-block;
        }
        form {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 15px;
            width: 300px;
            border-radius: 5px;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="submit"] {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        a {
            color: blue;
            text-decoration: none;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <h3>LOGIN</h3>
    <form action="registration.html" method="post">
        <label for="user_id">User Id</label>
        <input type="text" id="user_id" name="user_id" required>
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        
        <input type="submit" value="Login">
        <a href="shimu_reg.php">Register</a>
    </form>
</body>
</html>
